"""myproject URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, re_path
from app import views
from django.contrib.auth.views import LoginView, LogoutView
from additem import views as additem_views
admin.autodiscover()

urlpatterns = [
    path('admin/', admin.site.urls),

    # Main Website Views
    path('', views.home, name="home"),
    path('contact/', views.contact, name="contact"),
    path('about/', views.about, name="about"),
    path('menu/', views.menu, name="menu"),

    path('technical-support/', views.technical_support, name="technical_support"),
    path('system-update/', views.system_update, name="system_update"),
    path('manage-report/', views.manage_report, name="manage_report"),

    path('admin_dashboard/',views.admin_dashboard, name='admin_dashboard'),

    re_path(r'^login/$', LoginView.as_view(template_name = 'app/login.html'), name='login'),
    re_path(r'^logout$', LogoutView.as_view(template_name = 'app/index.html'), name='logout'),

    path('menu/module1/', views.module1, name='module1'),
    path('menu/module2/', views.module2, name='module2'),
    path('menu/module3/', views.module3, name='module3'),
    path('menu/module4/', views.module4, name='module4'),
    re_path(r'^module1/$', views.module1, name='module1'),
    re_path(r'^module2/$', views.module2, name='module2'),
    re_path(r'^module3/$', views.module3, name='module3'),
    re_path(r'^module4/$', views.module4, name='module4'),
    re_path(r'^add_expense$', views.add_expense, name='add_expense'),
    re_path(r'^add_income$', views.add_income, name='add_income'),
    re_path(r'^set_goal$', views.set_goal, name='set_goal'),
    re_path(r'^complete_goal/(?P<goal_id>\d+)$', views.complete_goal, name='complete_goal'),
    re_path(r'^delete_goal/(?P<goal_id>\d+)$', views.delete_goal, name='delete_goal'),
    path('reset_password/', views.reset_password, name='reset_password'),
    path('signup/', views.signup, name='signup'),
    path('upgrade/', views.request_upgrade, name='request_upgrade'),
    path("notifications/", views.notifications, name="notifications"),
    path('notifications/<int:notification_id>/', views.mark_notification_as_read, name='mark_notification_as_read'),
]
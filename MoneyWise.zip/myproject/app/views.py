from django.shortcuts import render, redirect, get_object_or_404

# Create your views here.
import uuid
from django.http import HttpRequest
from django.contrib.auth.models import User, Group
from django.contrib import messages
from datetime import datetime
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib.auth.hashers import make_password
from .forms import SignUpForm, TransactionForm, GoalForm, SystemUpdateForm, TechnicalSupportForm, ManageReportForm
from .models import Goal, Transaction, Issue, UpgradeRequest, Notification, SystemUpdate, TechnicalSupport, ManageReport

"""from django.contrib.auth import authenticate, login
from django.contrib.auth.forms import AuthenticationForm
from django.contrib import messages
from .models import UpgradeRequest
from .forms import UpgradeRequestForm"""

def home(request):
    """Renders the home page."""
    assert isinstance(request, HttpRequest)
    if request.user.is_authenticated:
        return(redirect('/menu'))
    else:
        return render(
            request,
            'app/index.html',
            {
                'title':'Home Page',
                'year': datetime.now().year,
            }
        )

def contact(request):
    """Renders the contact page."""
    assert isinstance(request, HttpRequest)
    contacts = [
        {'name': 'Fakhira Batrisyia', 'phone': '016-532 7266'},
        {'name': 'Nur Ain Natasha', 'phone': '014-805 5782'},
        {'name': 'Zainab Luqman', 'phone': '018-408 9343'},
        {'name': 'Arina Aghaee', 'phone': '011-3691 6163'}
    ]
    return render(
        request,
        'app/contact.html',
        {
            'title': 'Contact',
            'contacts': contacts,
            'year': datetime.now().year,
        }
    )

def about(request):
    """Renders the about page."""
    assert isinstance(request, HttpRequest)
    return render(
        request,
        'app/about.html',
        {
            'title':'MoneyWise',
            'message':'Our Personal Budget Tracker system is designed to help users better manage their finances by providing a streamlined platform to track income, expenses, and financial goals. Its intuitive interface combines robust functionalities to enable smooth interactions and informed decision-making for users. ',
            'year':datetime.now().year,
        }
    )

def reset_password(request):
    """Simple password reset view."""
    if request.method == 'POST':
        username = request.POST.get('username')
        new_password = request.POST.get('new_password')
        confirm_password = request.POST.get('confirm_password')
        
        try:
            user = User.objects.get(username=username)
            if new_password == confirm_password:
                user.password = make_password(new_password)
                user.save()
                messages.success(request, 'Password has been reset successfully.')
                return redirect('login')
            else:
                messages.error(request, 'Passwords do not match.')
        except User.DoesNotExist:
            messages.error(request, 'Username not found.')
        
    return render(
        request,
        'app/reset_password.html',
        {
            'title': 'Reset Password',
            'year': datetime.now().year,
        }
    )

@login_required
def menu(request):
    user = request.user

    is_basic = user.groups.filter(name="Basic User").exists()
    is_premium = user.groups.filter(name="Premium User").exists()
    is_it_support = user.groups.filter(name="IT Support").exists()

    return render(request, "app/menu.html", {
        "is_basic": is_basic,
        "is_premium": is_premium,
        "is_it_support": is_it_support,
    })

@login_required
def module1(request):
    """Renders module 1 page."""
    assert isinstance(request, HttpRequest)
    transactions = Transaction.objects.filter(user=request.user).order_by('-date')
    return render(
        request,
        'app/module1.html',
        {
            'title':'Module 1',
            'year':datetime.now().year,
            'transactions': transactions,
        }
    )

@login_required
def add_expense(request):
    """Handles adding an expense."""
    assert isinstance(request, HttpRequest)
    
    if request.method == 'POST':
        form = TransactionForm(request.POST)
        if form.is_valid():
            transaction = form.save(commit=False)
            transaction.user = request.user
            transaction.transaction_type = 'expense'
            transaction.save()
            return redirect('/module1')
    else:
        form = TransactionForm()
    
    return render(
        request,
        'app/add_expense.html',
        {
            'title':'Add Expense',
            'year':datetime.now().year,
            'form': form,
        }
    )

@login_required
def add_income(request):
    """Handles adding an income."""
    assert isinstance(request, HttpRequest)
    
    if request.method == 'POST':
        form = TransactionForm(request.POST)
        if form.is_valid():
            transaction = form.save(commit=False)
            transaction.user = request.user
            transaction.transaction_type = 'income'
            transaction.save()
            return redirect('/module1')
    else:
        form = TransactionForm()
    
    return render(
        request,
        'app/add_income.html',
        {
            'title':'Add Income',
            'year':datetime.now().year,
            'form': form,
        }
    )

@login_required
def module2(request):
    """Renders module 2 page with user's goals."""
    assert isinstance(request, HttpRequest)
    goals = Goal.objects.filter(user=request.user)
    return render(
        request,
        'app/module2.html',
        {
            'title':'Module 2',
            'year':datetime.now().year,
            'goals': goals,
        }
    )

@login_required
def complete_goal(request, goal_id):
    """Marks a goal as complete."""
    if request.method == 'POST':
        goal = Goal.objects.get(id=goal_id, user=request.user)
        goal.completed = True
        goal.save()
    return redirect('/module2')

@login_required
def delete_goal(request, goal_id):
    """Deletes a goal."""
    if request.method == 'POST':
        Goal.objects.filter(id=goal_id, user=request.user).delete()
    return redirect('/module2')

@login_required
def set_goal(request):
    """Handles setting a new goal."""
    assert isinstance(request, HttpRequest)
    
    if request.method == 'POST':
        form = GoalForm(request.POST)
        if form.is_valid():
            goal = form.save(commit=False)
            goal.user = request.user
            goal.save()
            return redirect('/module2')
    else:
        form = GoalForm()
    
    return render(
        request,
        'app/set_goal.html',
        {
            'title':'Set Goal',
            'year':datetime.now().year,
            'form': form,
        }
    )

@login_required
def module3(request):
    """Renders module 3 page - Financial Report."""
    assert isinstance(request, HttpRequest)
    transactions = Transaction.objects.filter(user=request.user).order_by('-date')
    goals = Goal.objects.filter(user=request.user)
    return render(
        request,
        'app/module3.html',
        {
            'title':'Financial Report',
            'year':datetime.now().year,
            'transactions': transactions,
            'goals': goals,
        }
    )

@login_required
def module4(request):
    """Renders module 4 page - Report Issues."""
    assert isinstance(request, HttpRequest)
    
    if request.method == 'POST':
        title = request.POST.get('title')
        description = request.POST.get('description')
        if title and description:
            Issue.objects.create(
                user=request.user,
                title=title,
                description=description
            )
            messages.success(request, 'Issue reported successfully.')
            return redirect('/module4')
    
    user_issues = Issue.objects.filter(user=request.user).order_by('-created_at')
    return render(
        request,
        'app/module4.html',
        {
            'title':'Report Issues',
            'year':datetime.now().year,
            'issues': user_issues,
        }
    )

def signup(request):
    if request.method == "POST":
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()  # Save the new user
            login(request, user)  # Log in the user after signup

            # Automatically add user to Basic User group
            basic_group, created = Group.objects.get_or_create(name="Basic User")
            user.groups.add(basic_group)

            # Create a welcome notification
            Notification.objects.create(
                user=user,
                message="Welcome to MoneyWise! You are now registered as a Basic User."
            )

            messages.success(request, "Registration successful! A welcome notification has been sent.")
            return redirect('/menu/')  # Redirect to menu after signup
        else:
            messages.error(request, "There was an error with your sign-up details.")

    else:
        form = SignUpForm()

    return render(request, "app/signup.html", {"form": form})

@login_required
def request_upgrade(request):
    user_request = UpgradeRequest.objects.filter(user=request.user).first()

    # Step 1: User submits upgrade request
    if request.method == "POST" and "submit_request" in request.POST:
        if user_request:
            messages.error(request, "You already submitted an upgrade request.")
        else:
            # Create a new upgrade request (payment step comes next)
            user_request = UpgradeRequest.objects.create(
                user=request.user,
                payment_status="pending",
                status="pending"
            )
            messages.success(request, "Upgrade request submitted! Please confirm your payment.")
        return redirect('/upgrade/')  # Redirect to the same page to show payment step

    # Step 2: User confirms payment
    elif request.method == "POST" and "submit_payment" in request.POST:
        if user_request and user_request.payment_status == "pending":
            user_request.transaction_id = str(uuid.uuid4())  # Generate a transaction ID
            user_request.payment_status = "successful"  # Mark as paid
            user_request.save()
            messages.success(request, f"Payment confirmed! Your transaction ID is: {user_request.transaction_id}")
        return redirect('/upgrade/')  # Refresh page to show transaction ID and status

    return render(request, "app/upgrade_request.html", {"user_request": user_request})

@login_required
def notifications(request):
    user_notifications = Notification.objects.filter(user=request.user).order_by('-created_at')
    return render(request, "app/notifications.html", {"notifications": user_notifications})

@login_required
def mark_notification_as_read(request, notification_id):
    notification = get_object_or_404(Notification, id=notification_id, user=request.user)
    notification.is_read = True  # Mark as read
    notification.save()
    return redirect('/notifications/')  # Redirect back to notifications page

@login_required
def system_update(request):
    if request.method == 'POST':
        form = SystemUpdateForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('system_update')  # Redirect to refresh the page
    else:
        form = SystemUpdateForm()
    
    updates = SystemUpdate.objects.all()  # Fetch saved updates
    return render(request, 'app/system_update.html', {'form': form, 'updates': updates})

@login_required
def technical_support(request):
    if request.method == 'POST':
        form = TechnicalSupportForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('technical_support')  # Refresh after submitting
    else:
        form = TechnicalSupportForm()
    
    tickets = TechnicalSupport.objects.all()  # Fetch all tickets
    return render(request, 'app/technical_support.html', {'form': form, 'tickets': tickets})

@login_required
def manage_report(request):
    if request.method == 'POST':
        form = ManageReportForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('manage_report')  # Refresh after submitting
    else:
        form = ManageReportForm()
    
    reports = ManageReport.objects.all()  # Fetch all reports
    return render(request, 'app/manage_report.html', {'form': form, 'reports': reports})

@login_required
def admin_dashboard(request):
    if not request.user.is_superuser:
        return redirect('menu')  # Redirect non-admins to menu
    
    return render(request, 'app/admin_dashboard.html', {
        'title': 'Admin Dashboard',
        'year': datetime.now().year
    })
class ITSupportRouter:
    def db_for_read(self, model, **hints):
        """Point IT support models to the 'itsupport_db' database."""
        if model._meta.app_label == 'itsupport':
            return 'itsupport_db'
        return None

    def db_for_write(self, model, **hints):
        """Point IT support models to the 'itsupport_db' database."""
        if model._meta.app_label == 'itsupport':
            return 'itsupport_db'
        return None

    def allow_migrate(self, db, app_label, model_name=None, **hints):
        """Ensure only IT support models go to 'itsupport_db'."""
        if app_label == 'itsupport':
            return db == 'itsupport_db'
        return db == 'default'
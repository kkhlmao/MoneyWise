from django.contrib import admin
from .models import Item, UpgradeRequest, Notification, ManageReport, SystemUpdate, TechnicalSupport
from django.contrib.auth.models import User, Group
from django import forms
from django.utils.translation import gettext_lazy as _

admin.site.register(Item)
admin.site.unregister(Item)

admin.site.site_header = "MoneyWise Administration"
admin.site.site_title = "MoneyWise Admin"
admin.site.index_title = "Welcome to MoneyWise Admin Panel"

# IT Support Admin Restrictions
class ITSupportAdmin(admin.ModelAdmin):
    def has_module_permission(self, request):
        """Only allow IT Support users to see their models"""
        if request.user.is_superuser:
            return True  # Superuser sees everything
        
        # IT Support should only see these apps
        allowed_apps = {"ManageReport", "SystemUpdate", "TechnicalSupport"}
        return self.model.__name__ in allowed_apps

admin.site.register(ManageReport, ITSupportAdmin)
admin.site.register(SystemUpdate, ITSupportAdmin)
admin.site.register(TechnicalSupport, ITSupportAdmin)

@admin.register(UpgradeRequest)
class UpgradeRequestAdmin(admin.ModelAdmin):
    list_display = ("user", "status", "payment_status", "transaction_id", "request_date")
    list_filter = ("status", "payment_status")
    actions = ["approve_request", "reject_request"]

    def approve_request(self, request, queryset):
        for request_obj in queryset:
            if request_obj.payment_status == "successful" and request_obj.status != "approved":
                request_obj.status = "approved"
                request_obj.save()

                #Move user from Basic User to Premium User group
                user = request_obj.user
                basic_group = Group.objects.get(name="Basic User")
                premium_group = Group.objects.get(name="Premium User")

                user.groups.remove(basic_group)  # Remove from Basic
                user.groups.add(premium_group)  # Add to Premium
                user.save()

                #Automatically send notification
                Notification.objects.create(
                    user=user,
                    message="Your upgrade request has been approved! You are now a Premium User."
                )
        self.message_user(request, "Selected upgrade requests have been approved, users upgraded, and notified.")

    def reject_request(self, request, queryset):
        for request_obj in queryset:
            if request_obj.status != "rejected":
                request_obj.status = "rejected"
                request_obj.payment_status = "failed"  # Mark payment as failed
                request_obj.save()

                # Automatically send rejection notification
                Notification.objects.create(
                    user=request_obj.user,
                    message="Your upgrade request was rejected. Please contact support for more details."
                )
        self.message_user(request, "Selected upgrade requests have been rejected and users notified.")

class NotificationForm(forms.Form):
    users = forms.ModelMultipleChoiceField(queryset=User.objects.all(), widget=admin.widgets.FilteredSelectMultiple("Users", is_stacked=False))
    message = forms.CharField(widget=forms.Textarea, help_text="Enter the notification message.")

@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = ("user", "message", "is_read", "created_at")
    list_filter = ("is_read",)
    actions = ["mark_as_read"]

    def mark_as_read(self, request, queryset):
        queryset.update(is_read=True)
        self.message_user(request, "Selected notifications marked as read.")

    mark_as_read.short_description = "Mark selected notifications as read"
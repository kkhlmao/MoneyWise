"""
Definition of forms.
"""

from django import forms
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from django.utils.translation import gettext_lazy as _
from .models import User, UpgradeRequest, Transaction, Goal, SystemUpdate, TechnicalSupport, ManageReport

class BootstrapAuthenticationForm(AuthenticationForm):
    """Authentication form which uses bootstrap CSS."""
    username = forms.CharField(max_length=254,
                               widget=forms.TextInput({
                                   'class': 'form-control',
                                   'placeholder': 'User name'}))
    password = forms.CharField(label=_("Password"),
                               widget=forms.PasswordInput({
                                   'class': 'form-control',
                                   'placeholder':'Password'}))
    
class UpgradeRequestForm(forms.ModelForm):
    transaction_id = forms.CharField(
        required=True,
        label="Payment Transaction ID",
        help_text="Enter the transaction ID after completing payment."
    )

    class Meta:
        model = UpgradeRequest
        fields = ['transaction_id']

class TransactionForm(forms.ModelForm):
    date = forms.DateField(
        required=True,
        widget=forms.DateInput(attrs={"placeholder": "YYYY-MM-DD", "type": "date"})
    )

    class Meta:
        model = Transaction
        fields = ['date', 'description', 'amount']

class GoalForm(forms.ModelForm):
    target_date = forms.DateField(
        required=True,
        widget=forms.DateInput(
            attrs={"placeholder": "YYYY-MM-DD", "type": "date"}
        )
    )

    class Meta:
        model = Goal
        fields = ['title', 'description', 'target_date']

class SignUpForm(UserCreationForm):
    email = forms.EmailField(
        required=True,
        widget=forms.EmailInput(attrs={"placeholder": "example@example.com"}),
        error_messages={"invalid": "Please enter a valid email address."}
    )

    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']

class SystemUpdateForm(forms.ModelForm):
    class Meta:
        model = SystemUpdate
        fields = ['title', 'description']

class TechnicalSupportForm(forms.ModelForm):
    class Meta:
        model = TechnicalSupport
        fields = ['user', 'issue', 'status']

class ManageReportForm(forms.ModelForm):
    class Meta:
        model = ManageReport
        fields = ['title', 'content']